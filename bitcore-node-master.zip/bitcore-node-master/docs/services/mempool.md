# Mempool Service

The mempool service provides a mempool transaction index for the Bitcoin blockchain. Specifically, it maintains a larger index of mempool transactions than a typical full node can manage on its own.

- transaction id
- transaction

This service is generally used to support other services and is not used externally.

## Service Configuration

none

## Other services this service Depends on

- db
