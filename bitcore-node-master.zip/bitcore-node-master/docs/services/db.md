# Db Service

The db service provides an abstraction over the underlying database used to store the indexes in bitcore-node.

## Service Configuration

None

## Other services this service Depends on

None


