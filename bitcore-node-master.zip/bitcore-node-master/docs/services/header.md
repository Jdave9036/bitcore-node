# Header Service

The header service provides a header index for the Bitcoin blockchain. Specifically, it builds and maintains the following information about every bitcoin block header:

- block hash
- block height
- block header

This service is generally used to support other services and is not used externally.

## Service Configuration

none

## Other services this service Depends on

- db
- p2p

